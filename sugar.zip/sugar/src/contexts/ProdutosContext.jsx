import { createContext, useContext, useState } from 'react';

const ProdutosContext = createContext();

export function ProdutosProvider({ children }) {
  const [produtos, setProdutos] = useState([
    { id: 1, nome: 'Cupcake', preco: '15 R$', descricao: 'Um pequeno bolo', desconto: true },
    { id: 2, nome: 'Cupcake', preco: '15 R$', descricao: 'Um pequeno bolo', desconto: false },
    { id: 3, nome: 'Cupcake', preco: '15 R$', descricao: 'Um pequeno bolo', desconto: false }
  ]);

  return (
    <ProdutosContext.Provider value={{ produtos, setProdutos }}>
      {children}
    </ProdutosContext.Provider>
  );
}

export function useProdutos() {
  return useContext(ProdutosContext);
}