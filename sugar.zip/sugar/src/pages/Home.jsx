import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import '../App.css';
import { useProdutos } from '../contexts/ProdutosContext';

const handleHomeClick = () => {
  navigate('/');
};

function Home() {
  const navigate = useNavigate();
  const { produtos, setProdutos } = useProdutos();

  // Estados para os campos do formulário
  const [nome, setNome] = useState('Cupcake');
  const [preco, setPreco] = useState('15 R$');
  const [descricao, setDescricao] = useState('Um pequeno bolo');

  // Função para adicionar um novo produto
  const adicionarProduto = () => {
    const novoProduto = {
      id: produtos.length + 1,
      nome,
      preco,
      descricao,
      desconto: false
    };
    setProdutos([...produtos, novoProduto]);
    setNome('');
    setPreco('');
    setDescricao('');
  };

  return (
    <div className="app">
      {/* Cabeçalho */}
      <header className="header">
        <div className="logo">Sugar Rush</div>
        <nav>
          <span onClick={handleHomeClick}>Home</span> | <span onClick={() => navigate('/carrinho')} style={{ cursor: 'pointer' }}>Carrinho</span>
        </nav>
      </header>

      {/* Seção de Boas-vindas */}
      <section className="welcome-section">
        <h1>Welcome</h1>
        <h2>Craving Sugar?</h2>
      </section>

      {/* Seção de Produtos */}
      <section className="products-section">
        {produtos.map((produto) => (
          <div
            key={produto.id}
            className={`product-card${produto.desconto ? ' discount' : ''}`}
            onClick={() => navigate('/produto', { state: { produto } })}
            style={{ cursor: 'pointer' }}
          >
            {produto.desconto && <div className="discount-badge">-30%</div>}
            <div className="product-icon">🧁</div>
            <p>{produto.nome}</p>
          </div>
        ))}
      </section>

      {/* Detalhes do Produto */}
      <section className="product-details">
        <div className="details-info">
          <div className="input-group">
            <label>Nome do produto</label>
            <input
              type="text"
              value={nome}
              placeholder="Cupcake"
              onChange={e => setNome(e.target.value)}
            />
          </div>
          <div className="input-group">
            <label>Preço</label>
            <input
              type="text"
              value={preco}
              placeholder="15 R$"
              onChange={e => setPreco(e.target.value)}
            />
          </div>
          <div className="input-group">
            <label>Descrição</label>
            <input
              type="text"
              value={descricao}
              placeholder="Um pequeno bolo"
              onChange={e => setDescricao(e.target.value)}
            />
          </div>
        </div>
        <button className="add-button" onClick={adicionarProduto}>+</button>
      </section>
    </div>
  );
}

export default Home;
