import { useCarrinho } from '../contexts/CarrinhoContext';
import { useNavigate } from 'react-router-dom';

function Carrinho() {
  const { carrinho } = useCarrinho();
  const navigate = useNavigate();

  const handleHomeClick = () => {
    navigate('/');
  };

  return (
    <div className="app">
      <header className="header">
        <div className="logo">Sugar Rush</div>
        <nav>
          <span onClick={handleHomeClick}>Home</span> | <span style={{ fontWeight: 'bold' }}>Carrinho</span>
        </nav>
      </header>
      <section className="carrinho-section">
        <h1>Carrinho</h1>
        {carrinho.length === 0 ? (
          <p>Seu carrinho está vazio.</p>
        ) : (
          <ul>
            {carrinho.map(item => (
              <li key={item.id} style={{ marginBottom: 16 }}>
                <strong>{item.nome}</strong> — {item.quantidade}x
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

export default Carrinho;