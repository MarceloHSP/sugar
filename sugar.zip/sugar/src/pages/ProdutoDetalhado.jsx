import { useLocation, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import '../App.css';
import { useCarrinho } from '../contexts/CarrinhoContext';

function ProdutoDetalhado() {
  const location = useLocation();
  const navigate = useNavigate();
  const produto = location.state?.produto;
  const [quantidade, setQuantidade] = useState(1);
  const [showDropdown, setShowDropdown] = useState(false);
  const { adicionarAoCarrinho } = useCarrinho();

  if (!produto) {
    // Se não veio produto, volta para home
    navigate('/');
    return null;
  }

  const handleHomeClick = () => {
    navigate('/');
  };

  const handleQuantidadeClick = () => {
    setShowDropdown(!showDropdown);
  };

  const selectQuantidade = (value) => {
    setQuantidade(value);
    setShowDropdown(false);
  };

  return (
    <div className="app">
      <header className="header">
        <div className="logo">Sugar Rush</div>
        <nav>
          <span onClick={handleHomeClick}>Home</span> | <span onClick={() => navigate('/carrinho')} style={{ cursor: 'pointer' }}>Carrinho</span>
        </nav>
      </header>

      <div className="produto-detalhado-container">
        {/* Preço à esquerda */}
        <div className="produto-imagem" style={{ width: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div>
                      <div
            key={produto.id}
            className={`product-card${produto.desconto ? ' discount' : ''}`}
            onClick={() => navigate('/produto', { state: { produto } })}
            style={{ cursor: 'pointer' }}
          >
            {produto.desconto && <div className="discount-badge">-30%</div>}
            <div className="product-icon">🧁</div>
            <p>{produto.nome}</p>
          </div>
          <div className="produto-preco" style={{ fontSize: '2.5rem', color: '#fff', marginTop: '20px' }}>{produto.preco}</div>
          </div>
        </div>
        {/* Descrição à direita */}
        <div className="produto-info" style={{ width: '50%', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', padding: '40px' }}>
          <h1>{produto.descricao}</h1>
          
          <div className="produto-controls">
            <div className="quantidade-selector">
              <label>Quantidade</label>
              <div className="dropdown" onClick={handleQuantidadeClick}>
                <div className="selected-value">{quantidade}</div>
                {showDropdown && (
                  <div className="dropdown-content">
                    <div className="dropdown-item" onClick={() => selectQuantidade(1)}>1</div>
                    <div className="dropdown-item" onClick={() => selectQuantidade(2)}>2</div>
                    <div className="dropdown-item" onClick={() => selectQuantidade(3)}>3</div>
                  </div>
                )}
              </div>
            </div>
            
            <button
              className="add-button"
              onClick={() => {
                adicionarAoCarrinho(produto, quantidade)
                navigate('/carrinho');
              }}
            >
              +
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProdutoDetalhado;